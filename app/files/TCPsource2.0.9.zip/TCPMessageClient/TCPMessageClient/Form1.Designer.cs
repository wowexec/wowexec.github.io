﻿namespace TCPMessageClient
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.portText = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textLog = new System.Windows.Forms.RichTextBox();
            this.sendMsg = new System.Windows.Forms.RichTextBox();
            this.sendBtn = new System.Windows.Forms.Button();
            this.ipText = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.ReceivedFilenameTxt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.choosefileBtn = new System.Windows.Forms.Button();
            this.sendfileBtn = new System.Windows.Forms.Button();
            this.FilenameTxt = new System.Windows.Forms.TextBox();
            this.pathTxt = new System.Windows.Forms.RichTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.cmdBtn = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // portText
            // 
            this.portText.Location = new System.Drawing.Point(212, 12);
            this.portText.Name = "portText";
            this.portText.PlaceholderText = "Port";
            this.portText.Size = new System.Drawing.Size(56, 27);
            this.portText.TabIndex = 1;
            this.portText.Text = "7010";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(274, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 2;
            this.button1.Tag = "";
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(374, 10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 3;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textLog
            // 
            this.textLog.Location = new System.Drawing.Point(12, 45);
            this.textLog.Name = "textLog";
            this.textLog.ReadOnly = true;
            this.textLog.Size = new System.Drawing.Size(776, 178);
            this.textLog.TabIndex = 4;
            this.textLog.Text = "";
            this.textLog.TextChanged += new System.EventHandler(this.textLog_TextChanged);
            // 
            // sendMsg
            // 
            this.sendMsg.Location = new System.Drawing.Point(12, 229);
            this.sendMsg.Name = "sendMsg";
            this.sendMsg.Size = new System.Drawing.Size(776, 201);
            this.sendMsg.TabIndex = 5;
            this.sendMsg.Text = "";
            // 
            // sendBtn
            // 
            this.sendBtn.Location = new System.Drawing.Point(12, 436);
            this.sendBtn.Name = "sendBtn";
            this.sendBtn.Size = new System.Drawing.Size(94, 29);
            this.sendBtn.TabIndex = 6;
            this.sendBtn.Text = "Send";
            this.sendBtn.UseVisualStyleBackColor = true;
            this.sendBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // ipText
            // 
            this.ipText.FormattingEnabled = true;
            this.ipText.Items.AddRange(new object[] {
            "192.168.3.34",
            "192.168.100.13",
            "192.168.3.6",
            "192.168.3.5",
            "127.0.0.1"});
            this.ipText.Location = new System.Drawing.Point(12, 12);
            this.ipText.Name = "ipText";
            this.ipText.Size = new System.Drawing.Size(194, 28);
            this.ipText.TabIndex = 8;
            this.ipText.Text = "192.168.3.34";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(474, 10);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 9;
            this.button3.Text = "HideMe";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "TCPClient";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // ReceivedFilenameTxt
            // 
            this.ReceivedFilenameTxt.Location = new System.Drawing.Point(12, 707);
            this.ReceivedFilenameTxt.Name = "ReceivedFilenameTxt";
            this.ReceivedFilenameTxt.Size = new System.Drawing.Size(776, 27);
            this.ReceivedFilenameTxt.TabIndex = 10;
            this.ReceivedFilenameTxt.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.choosefileBtn);
            this.groupBox1.Controls.Add(this.sendfileBtn);
            this.groupBox1.Controls.Add(this.FilenameTxt);
            this.groupBox1.Controls.Add(this.pathTxt);
            this.groupBox1.Location = new System.Drawing.Point(12, 502);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 183);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File";
            // 
            // choosefileBtn
            // 
            this.choosefileBtn.Location = new System.Drawing.Point(7, 145);
            this.choosefileBtn.Name = "choosefileBtn";
            this.choosefileBtn.Size = new System.Drawing.Size(94, 29);
            this.choosefileBtn.TabIndex = 3;
            this.choosefileBtn.Text = "Choose";
            this.choosefileBtn.UseVisualStyleBackColor = true;
            this.choosefileBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // sendfileBtn
            // 
            this.sendfileBtn.Location = new System.Drawing.Point(676, 145);
            this.sendfileBtn.Name = "sendfileBtn";
            this.sendfileBtn.Size = new System.Drawing.Size(94, 29);
            this.sendfileBtn.TabIndex = 2;
            this.sendfileBtn.Text = "Send";
            this.sendfileBtn.UseVisualStyleBackColor = true;
            this.sendfileBtn.Click += new System.EventHandler(this.sendfileBtn_Click);
            // 
            // FilenameTxt
            // 
            this.FilenameTxt.Location = new System.Drawing.Point(7, 112);
            this.FilenameTxt.Name = "FilenameTxt";
            this.FilenameTxt.PlaceholderText = "Filename";
            this.FilenameTxt.ReadOnly = true;
            this.FilenameTxt.Size = new System.Drawing.Size(763, 27);
            this.FilenameTxt.TabIndex = 1;
            // 
            // pathTxt
            // 
            this.pathTxt.Location = new System.Drawing.Point(7, 26);
            this.pathTxt.Name = "pathTxt";
            this.pathTxt.ReadOnly = true;
            this.pathTxt.Size = new System.Drawing.Size(763, 80);
            this.pathTxt.TabIndex = 0;
            this.pathTxt.Text = "";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(112, 436);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(94, 29);
            this.button4.TabIndex = 12;
            this.button4.Text = "GetScreen";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // cmdBtn
            // 
            this.cmdBtn.Location = new System.Drawing.Point(212, 436);
            this.cmdBtn.Name = "cmdBtn";
            this.cmdBtn.Size = new System.Drawing.Size(94, 29);
            this.cmdBtn.TabIndex = 14;
            this.cmdBtn.Text = "Command";
            this.cmdBtn.UseVisualStyleBackColor = true;
            this.cmdBtn.Click += new System.EventHandler(this.cmdBtn_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(312, 436);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(94, 29);
            this.button6.TabIndex = 15;
            this.button6.Text = "MsgBox";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(412, 436);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(94, 29);
            this.button7.TabIndex = 16;
            this.button7.Text = "Shake";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(512, 436);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(94, 29);
            this.button8.TabIndex = 17;
            this.button8.Text = "Hide";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(612, 436);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(176, 29);
            this.button5.TabIndex = 18;
            this.button5.Text = "HideNotifyIcon";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(612, 471);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(176, 29);
            this.button9.TabIndex = 19;
            this.button9.Text = "ShowNotifyIcon";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 471);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(94, 29);
            this.button10.TabIndex = 20;
            this.button10.Text = "PressKey";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(112, 471);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(94, 29);
            this.button11.TabIndex = 21;
            this.button11.Text = "*KeyCode";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(512, 471);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(94, 29);
            this.button12.TabIndex = 22;
            this.button12.Text = "Show";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 694);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.cmdBtn);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ReceivedFilenameTxt);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.ipText);
            this.Controls.Add(this.sendBtn);
            this.Controls.Add(this.sendMsg);
            this.Controls.Add(this.textLog);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.portText);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Client";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox portText;
        private Button button1;
        private Button button2;
        private RichTextBox textLog;
        private RichTextBox sendMsg;
        private Button sendBtn;
        private ComboBox ipText;
        private Button button3;
        private NotifyIcon notifyIcon1;
        private TextBox ReceivedFilenameTxt;
        private GroupBox groupBox1;
        private Button sendfileBtn;
        private TextBox FilenameTxt;
        private RichTextBox pathTxt;
        private Button choosefileBtn;
        private Button button4;
        private Button cmdBtn;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button5;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
    }
}