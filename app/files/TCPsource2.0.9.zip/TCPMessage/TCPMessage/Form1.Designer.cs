﻿namespace TCPMessage
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textServerIP = new System.Windows.Forms.TextBox();
            this.textServerPort = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.clientCombo = new System.Windows.Forms.ComboBox();
            this.textLog = new System.Windows.Forms.RichTextBox();
            this.textMsg = new System.Windows.Forms.RichTextBox();
            this.pathTxt = new System.Windows.Forms.RichTextBox();
            this.choosefileBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FilenameTxt = new System.Windows.Forms.TextBox();
            this.cmdBtn = new System.Windows.Forms.Button();
            this.msgboxBtn = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.ReceivedFilenameTxt = new System.Windows.Forms.TextBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.hidemeBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // textServerIP
            // 
            this.textServerIP.Location = new System.Drawing.Point(22, 12);
            this.textServerIP.Name = "textServerIP";
            this.textServerIP.PlaceholderText = "IP";
            this.textServerIP.Size = new System.Drawing.Size(190, 27);
            this.textServerIP.TabIndex = 0;
            this.textServerIP.Tag = "";
            this.textServerIP.Text = "127.0.0.1";
            // 
            // textServerPort
            // 
            this.textServerPort.Location = new System.Drawing.Point(217, 12);
            this.textServerPort.Name = "textServerPort";
            this.textServerPort.PlaceholderText = "Port";
            this.textServerPort.Size = new System.Drawing.Size(55, 27);
            this.textServerPort.TabIndex = 1;
            this.textServerPort.Text = "7010";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(278, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 29);
            this.button1.TabIndex = 2;
            this.button1.Text = "Listen";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // clientCombo
            // 
            this.clientCombo.FormattingEnabled = true;
            this.clientCombo.Location = new System.Drawing.Point(366, 12);
            this.clientCombo.Name = "clientCombo";
            this.clientCombo.Size = new System.Drawing.Size(204, 28);
            this.clientCombo.TabIndex = 3;
            // 
            // textLog
            // 
            this.textLog.Location = new System.Drawing.Point(21, 47);
            this.textLog.Name = "textLog";
            this.textLog.ReadOnly = true;
            this.textLog.Size = new System.Drawing.Size(781, 179);
            this.textLog.TabIndex = 4;
            this.textLog.Text = "";
            // 
            // textMsg
            // 
            this.textMsg.Location = new System.Drawing.Point(21, 232);
            this.textMsg.Name = "textMsg";
            this.textMsg.Size = new System.Drawing.Size(781, 189);
            this.textMsg.TabIndex = 5;
            this.textMsg.Text = "";
            this.textMsg.TextChanged += new System.EventHandler(this.textMsg_TextChanged);
            // 
            // pathTxt
            // 
            this.pathTxt.Location = new System.Drawing.Point(6, 26);
            this.pathTxt.Name = "pathTxt";
            this.pathTxt.ReadOnly = true;
            this.pathTxt.Size = new System.Drawing.Size(769, 71);
            this.pathTxt.TabIndex = 6;
            this.pathTxt.Text = "";
            // 
            // choosefileBtn
            // 
            this.choosefileBtn.Location = new System.Drawing.Point(6, 136);
            this.choosefileBtn.Name = "choosefileBtn";
            this.choosefileBtn.Size = new System.Drawing.Size(94, 29);
            this.choosefileBtn.TabIndex = 7;
            this.choosefileBtn.Text = "Choose";
            this.choosefileBtn.UseVisualStyleBackColor = true;
            this.choosefileBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(681, 136);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 8;
            this.button3.Text = "Send";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(17, 427);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(94, 29);
            this.button4.TabIndex = 9;
            this.button4.Text = "Send";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(708, 427);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(94, 29);
            this.button5.TabIndex = 10;
            this.button5.Text = "Shake";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FilenameTxt);
            this.groupBox1.Controls.Add(this.pathTxt);
            this.groupBox1.Controls.Add(this.choosefileBtn);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Location = new System.Drawing.Point(21, 462);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(781, 178);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File";
            // 
            // FilenameTxt
            // 
            this.FilenameTxt.Location = new System.Drawing.Point(6, 103);
            this.FilenameTxt.Name = "FilenameTxt";
            this.FilenameTxt.PlaceholderText = "Filename";
            this.FilenameTxt.ReadOnly = true;
            this.FilenameTxt.Size = new System.Drawing.Size(769, 27);
            this.FilenameTxt.TabIndex = 9;
            // 
            // cmdBtn
            // 
            this.cmdBtn.Location = new System.Drawing.Point(117, 427);
            this.cmdBtn.Name = "cmdBtn";
            this.cmdBtn.Size = new System.Drawing.Size(94, 29);
            this.cmdBtn.TabIndex = 12;
            this.cmdBtn.Text = "Command";
            this.cmdBtn.UseVisualStyleBackColor = true;
            this.cmdBtn.Click += new System.EventHandler(this.cmdBtn_Click);
            // 
            // msgboxBtn
            // 
            this.msgboxBtn.Location = new System.Drawing.Point(217, 427);
            this.msgboxBtn.Name = "msgboxBtn";
            this.msgboxBtn.Size = new System.Drawing.Size(94, 29);
            this.msgboxBtn.TabIndex = 13;
            this.msgboxBtn.Text = "msgBox";
            this.msgboxBtn.UseVisualStyleBackColor = true;
            this.msgboxBtn.Click += new System.EventHandler(this.msgboxBtn_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(608, 427);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(94, 29);
            this.button6.TabIndex = 14;
            this.button6.Text = "Hide";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Location = new System.Drawing.Point(23, 755);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(676, 68);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Client Connection";
            this.groupBox2.Visible = false;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(576, 25);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(94, 29);
            this.button7.TabIndex = 1;
            this.button7.Text = "Execute";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "192.168.3.34",
            "192.168.100.13",
            "192.168.3.6",
            "192.168.3.5",
            "127.0.0.1"});
            this.comboBox1.Location = new System.Drawing.Point(6, 26);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(230, 28);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Visible = false;
            // 
            // ReceivedFilenameTxt
            // 
            this.ReceivedFilenameTxt.Location = new System.Drawing.Point(23, 829);
            this.ReceivedFilenameTxt.Name = "ReceivedFilenameTxt";
            this.ReceivedFilenameTxt.Size = new System.Drawing.Size(670, 27);
            this.ReceivedFilenameTxt.TabIndex = 16;
            this.ReceivedFilenameTxt.Visible = false;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "TCPServer";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // hidemeBtn
            // 
            this.hidemeBtn.Location = new System.Drawing.Point(576, 12);
            this.hidemeBtn.Name = "hidemeBtn";
            this.hidemeBtn.Size = new System.Drawing.Size(94, 29);
            this.hidemeBtn.TabIndex = 17;
            this.hidemeBtn.Text = "HideMe";
            this.hidemeBtn.UseVisualStyleBackColor = true;
            this.hidemeBtn.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(676, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 29);
            this.button2.TabIndex = 18;
            this.button2.Text = "HideNotifyIcon";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 650);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.hidemeBtn);
            this.Controls.Add(this.ReceivedFilenameTxt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.msgboxBtn);
            this.Controls.Add(this.cmdBtn);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textMsg);
            this.Controls.Add(this.textLog);
            this.Controls.Add(this.clientCombo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textServerPort);
            this.Controls.Add(this.textServerIP);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textServerIP;
        private TextBox textServerPort;
        private Button button1;
        private ComboBox clientCombo;
        private RichTextBox textLog;
        private RichTextBox textMsg;
        private RichTextBox pathTxt;
        private Button choosefileBtn;
        private Button button3;
        private Button button4;
        private Button button5;
        private GroupBox groupBox1;
        private Button cmdBtn;
        private Button msgboxBtn;
        private Button button6;
        private GroupBox groupBox2;
        private Button button7;
        private ComboBox comboBox1;
        private TextBox FilenameTxt;
        private TextBox ReceivedFilenameTxt;
        private NotifyIcon notifyIcon1;
        private Button hidemeBtn;
        private Button button2;
    }
}