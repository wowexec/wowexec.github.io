using System;
using Office;
using Word;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.Reflection;
using System.Linq;
using System;
using System.Collections.Generic;
using MSWord = Microsoft.Office.Interop.Word;
using System.Buffers.Text;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace Word1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void FindAndReplace(Microsoft.Office.Interop.Word.Application WordApp, object findText, object replaceWithText)
        {
            object matchCase = true;
            object matchWholeWord = false;
            object matchWildCards = false;
            object matchSoundsLike = false;
            object nmatchAllWordForms = false;
            object forward = true;
            object format = false;
            object matchKashida = false;
            object matchDiacritics = false;
            object matchAlefHamza = false;
            object matchControl = false;
            object read_only = false;
            object visible = true;
            object replace = 2;
            object wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindContinue;
            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            WordApp.Selection.Find.Execute(ref findText, ref matchCase, ref matchWholeWord, ref matchWildCards, ref matchSoundsLike,
            ref nmatchAllWordForms, ref forward,
            ref wrap, ref format, ref replaceWithText,
            ref replaceAll, ref matchKashida,
            ref matchDiacritics, ref matchAlefHamza,
            ref matchControl);
        }

        private void msg()
        {
            MessageBox.Show("Finished.");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //textBox3.Focus();
        }


        private void button1_Click(object sender, EventArgs e) //�滻Ӣ�ı��
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            FindAndReplace(wordApp, ",", "��");
            //FindAndReplace(wordApp, ".", "��");
            FindAndReplace(wordApp, "!", "��");
            FindAndReplace(wordApp, "?", "��");
            FindAndReplace(wordApp, ":", "��");
            FindAndReplace(wordApp, ";", "��");
            FindAndReplace(wordApp, "[", "��");
            FindAndReplace(wordApp, "]", "��");
            FindAndReplace(wordApp, "(", "��");
            FindAndReplace(wordApp, ")", "��");
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button2_Click(object sender, EventArgs e) //ѡ���ļ�
        {
            try
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.InitialDirectory = @"D:";
                fileDialog.Title = "Choose";
                fileDialog.Filter = "Word Documents|*.doc;*.docx;*.rtf;*.txt;*.xml";
                fileDialog.ShowDialog();
                ofullpathtxt.Text = fileDialog.FileName.Replace("\\", "\\\\");
                opathnametxt.Text = Path.GetDirectoryName(fileDialog.FileName).Replace("\\", "\\\\"); //·��
                ofilenametxt.Text = Path.GetFileNameWithoutExtension(fileDialog.FileName); //�ļ���
                oextnametxt.Text = Path.GetExtension(fileDialog.FileName);//��չ��
                string onewpath = opathnametxt.Text + "\\\\" + ofilenametxt.Text + "-backup" + DateTime.Now.ToString("yyyyMMddHHmmss") + oextnametxt.Text;
                //MessageBox.Show(onewpath);
                File.Copy(ofullpathtxt.Text, onewpath, true);
            }
            catch { } //��ֹȡ��ѡ��ʱ����
        }

        private void button3_Click(object sender, EventArgs e) //ҳ�߾����
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            wordDoc.PageSetup.LeftMargin = 54.26f;
            wordDoc.PageSetup.BottomMargin = 55.97f;
            wordDoc.PageSetup.RightMargin = 54.26f;
            wordDoc.PageSetup.TopMargin = 51.14f;
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            if (comboBox1.Text == "1")
            {
                wordDoc.Paragraphs.LineSpacing = 12f;
            }
            else if (comboBox1.Text == "1.5")
            {
                wordDoc.Paragraphs.LineSpacing = 18f;
            }
            else if (comboBox1.Text == "1.2")
            {
                wordDoc.Paragraphs.LineSpacing = 14.4f;
            }
            else if (comboBox1.Text == "1.1")
            {
                wordDoc.Paragraphs.LineSpacing = 13.2f;
            }
            else if (comboBox1.Text == "1.3")
            {
                wordDoc.Paragraphs.LineSpacing = 15.6f;
            }
            else if (comboBox1.Text == "1.4")
            {
                wordDoc.Paragraphs.LineSpacing = 16.8f;
            }
            else if (comboBox1.Text == "2")
            {
                wordDoc.Paragraphs.LineSpacing = 24f;
            }
            else if (comboBox1.Text == "3")
            {
                wordDoc.Paragraphs.LineSpacing = 36f;
            }
            else
            {
                MessageBox.Show("������Ч���ĵ��޸ļ���������������ִ�����");
            }
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            wordApp.ActiveWindow.ActivePane.Selection.ParagraphFormat.Borders[MSWord.WdBorderType.wdBorderBottom].LineStyle = MSWord.WdLineStyle.wdLineStyleNone;
            wordApp.ActiveWindow.ActivePane.Selection.Borders[MSWord.WdBorderType.wdBorderBottom].Visible = false;
            wordApp.ActiveWindow.ActivePane.View.SeekView = MSWord.WdSeekView.wdSeekMainDocument;//
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            MSWord.Range range = wordDoc.Range();
            range.Select();
            range.Font.Name = textBox3.Text;
            range.Font.Name = textBox4.Text;
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            object missing = System.Reflection.Missing.Value;
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            wordDoc.PageSetup.FooterDistance = 45f;
            setFooter(ref wordApp);
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
            MessageBox.Show("��ѡ��ȥ��ҳü���ߣ�");
        }

        void setFooter(ref MSWord.Application app)
        {
            object missing = System.Reflection.Missing.Value;
            app.ActiveWindow.ActivePane.View.SeekView = Microsoft.Office.Interop.Word.WdSeekView.wdSeekCurrentPageFooter;
            app.ActiveWindow.ActivePane.Selection.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            app.ActiveWindow.Selection.Font.Name = "Times New Roman";
            //app.ActiveWindow.Selection.Font.Size = 25;
            app.ActiveWindow.Selection.TypeText("");
            Object CurrentPage = MSWord.WdFieldType.wdFieldPage;
            app.ActiveWindow.Selection.Fields.Add(app.ActiveWindow.Selection.Range, ref CurrentPage, ref missing, ref missing);
            app.ActiveWindow.Selection.TypeText(" / ");
            Object TotalPages = MSWord.WdFieldType.wdFieldNumPages;
            app.ActiveWindow.Selection.Fields.Add(app.ActiveWindow.Selection.Range, ref TotalPages, ref missing, ref missing);
            app.ActiveWindow.Selection.TypeText("");
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            FindAndReplace(wordApp, ".", "��");
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            FindAndReplace(wordApp, "^p^p", "^p");
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            FindAndReplace(wordApp, "^g", "");
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            MSWord.Range range = wordDoc.Range();
            range.Select();
            if (comboBox2.Text == "���")
            {
                range.Font.Size = 10.5f;
            }
            else if (comboBox2.Text == "11")
            {
                range.Font.Size = 11f;
            }
            else if (comboBox2.Text == "С��")
            {
                range.Font.Size = 12f;
            }
            else if (comboBox2.Text == "�ĺ�")
            {
                range.Font.Size = 14f;
            }
            else if (comboBox2.Text == "С��")
            {
                range.Font.Size = 15f;
            }
            else if (comboBox2.Text == "����")
            {
                range.Font.Size = 16f;
            }
            else if (comboBox2.Text == "С��")
            {
                range.Font.Size = 18f;
            }
            else if (comboBox2.Text == "����")
            {
                range.Font.Size = 22f;
            }
            else if (comboBox2.Text == "С��")
            {
                range.Font.Size = 9f;
            }
            else
            {
                MessageBox.Show("������Ч���ĵ��޸ļ���������������ִ�����");
            }
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            MSWord.Range range = wordDoc.Range();
            range.Select();
            range.Font.Color = MSWord.WdColor.wdColorBlack;
            wordDoc.Save();
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button13_Click(object sender, EventArgs e) //����Ϊ����
        {
            MSWord.Application wordApp = new MSWord.Application();
            MSWord.Document wordDoc = wordApp.Documents.Open(ofullpathtxt.Text);
            wordApp.Visible = false;
            wordDoc.Activate();
            MSWord.Range range = wordDoc.Range();
            range.Select();
            object missing = System.Reflection.Missing.Value;
            object format = MSWord.WdSaveFormat.wdFormatDocument;
            object savePath = opathnametxt.Text + ofilenametxt.Text + "-" + DateTime.Now.ToString("yyyyMMddHHmmss") + oextnametxt.Text;
            wordDoc.SaveAs(ref savePath, ref format, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
            wordDoc.Close();
            wordApp.Quit();
            msg();
        }

        private void button14_Click(object sender, EventArgs e)
        {
        }

        private void button14_Click_1(object sender, EventArgs e)
        {

        }
    }
}